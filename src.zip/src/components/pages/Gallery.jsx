import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Filter, X } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

// Import images
import project1 from '../../assets/C1YKTpWsG2qG.jpg';
import project2 from '../../assets/68CPjQfi43Ek.jpg';
import project3 from '../../assets/BjlXGtMw0xC2.jpg';
import project4 from '../../assets/wY1YF0qkrOFC.jpg';

const Gallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProject, setSelectedProject] = useState(null);

  const categories = [
    { id: 'all', name: 'Todos los Proyectos' },
    { id: 'brick', name: 'Albañilería de Ladrillo' },
    { id: 'stone', name: 'Piedra Natural' },
    { id: 'repair', name: 'Reparaciones' },
    { id: 'commercial', name: 'Proyectos Comerciales' },
    { id: 'residential', name: 'Proyectos Residenciales' }
  ];

  const projects = [
    {
      id: 1,
      title: "Patio de Piedra Natural Premium",
      category: "stone",
      type: "residential",
      location: "Little Rock, AR",
      year: "2024",
      description: "Hermoso patio de piedra natural con diseño geométrico moderno y acabados de lujo.",
      image: project3,
      details: "Proyecto residencial que transformó completamente el espacio exterior de esta propiedad. Utilizamos piedra natural de Arkansas con técnicas de instalación avanzadas para crear un patio duradero y estéticamente impresionante."
    },
    {
      id: 2,
      title: "Restauración de Fachada Histórica",
      category: "repair",
      type: "commercial",
      location: "North Little Rock, AR",
      year: "2023",
      description: "Restauración completa de fachada de ladrillo en edificio histórico del centro de la ciudad.",
      image: project2,
      details: "Proyecto de restauración que requirió técnicas especializadas para preservar la integridad histórica mientras se modernizaban los aspectos estructurales. Trabajo meticuloso de rejuntado y reemplazo selectivo de ladrillos."
    },
    {
      id: 3,
      title: "Muro de Contención Decorativo",
      category: "stone",
      type: "residential",
      location: "Conway, AR",
      year: "2024",
      description: "Muro de contención en piedra natural con elementos decorativos integrados.",
      image: project1,
      details: "Solución funcional y estética para un desnivel pronunciado en el terreno. Combinamos ingeniería estructural con diseño paisajístico para crear un elemento que es tanto funcional como hermoso."
    },
    {
      id: 4,
      title: "Complejo Comercial Moderno",
      category: "brick",
      type: "commercial",
      location: "Benton, AR",
      year: "2023",
      description: "Fachada de ladrillo moderno para complejo comercial de nueva construcción.",
      image: project4,
      details: "Proyecto comercial de gran escala que requirió coordinación precisa con otros contratistas. Instalación de más de 50,000 ladrillos con patrones geométricos complejos y acabados de alta calidad."
    },
    {
      id: 5,
      title: "Chimenea de Piedra Artesanal",
      category: "stone",
      type: "residential",
      location: "Hot Springs, AR",
      year: "2024",
      description: "Chimenea interior de piedra natural con diseño personalizado y acabados únicos.",
      image: project3,
      details: "Chimenea completamente personalizada utilizando piedra natural local. Diseño único que se integra perfectamente con la arquitectura existente de la vivienda."
    },
    {
      id: 6,
      title: "Reparación de Muro Perimetral",
      category: "repair",
      type: "residential",
      location: "Bryant, AR",
      year: "2023",
      description: "Reparación estructural y estética de muro perimetral de ladrillo antiguo.",
      image: project2,
      details: "Proyecto de reparación que involucró el refuerzo estructural de un muro perimetral de más de 50 años. Técnicas especializadas de reparación que extendieron la vida útil por décadas adicionales."
    }
  ];

  const filteredProjects = selectedCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  const openModal = (project) => {
    setSelectedProject(project);
  };

  const closeModal = () => {
    setSelectedProject(null);
  };

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container-custom text-center">
          <h1 className="text-responsive-xl font-bold text-primary mb-6">
            Galería de Proyectos Realizados
          </h1>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Explora nuestra colección de proyectos completados que demuestran nuestro compromiso 
            con la excelencia, la calidad y la construcción de sueños. Cada proyecto cuenta una 
            historia única de transformación y artesanía superior.
          </p>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 bg-white border-b">
        <div className="container-custom">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                  selectedCategory === category.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-gray-100 text-muted-foreground hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => (
              <Card 
                key={project.id} 
                className="gallery-item card-hover border-0 shadow-lg cursor-pointer"
                onClick={() => openModal(project)}
              >
                <div className="relative h-64 overflow-hidden rounded-t-lg">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="gallery-overlay">
                    <div className="text-center text-white">
                      <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                      <p className="text-sm opacity-90">Click para ver detalles</p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-lg font-semibold text-primary">{project.title}</h3>
                    <span className="text-sm text-accent font-medium">{project.year}</span>
                  </div>
                  <p className="text-muted-foreground text-sm mb-3 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground">{project.location}</span>
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs font-medium">
                      {project.type === 'residential' ? 'Residencial' : 'Comercial'}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-16">
              <Filter className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-primary mb-2">No se encontraron proyectos</h3>
              <p className="text-muted-foreground">
                No hay proyectos disponibles para la categoría seleccionada.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-responsive-lg font-bold mb-4">
              Nuestros Números Hablan
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Cada proyecto completado representa nuestro compromiso con la excelencia 
              y la satisfacción total de nuestros clientes.
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div className="space-y-2">
              <div className="text-4xl lg:text-5xl font-bold text-accent">500+</div>
              <div className="text-lg opacity-90">Proyectos Completados</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl lg:text-5xl font-bold text-accent">15+</div>
              <div className="text-lg opacity-90">Años de Experiencia</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl lg:text-5xl font-bold text-accent">100%</div>
              <div className="text-lg opacity-90">Clientes Satisfechos</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl lg:text-5xl font-bold text-accent">24/7</div>
              <div className="text-lg opacity-90">Soporte al Cliente</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-accent text-accent-foreground">
        <div className="container-custom text-center">
          <h2 className="text-responsive-lg font-bold mb-4">
            ¿Inspirado por Nuestro Trabajo?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            Cada uno de estos proyectos comenzó con una visión. Permítenos ayudarte a 
            materializar la tuya con la misma calidad, dedicación y profesionalismo.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/quote">
              <Button className="btn-primary text-lg px-8 py-4">
                Solicitar Cotización Gratuita
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="text-lg px-8 py-4 border-white/30 text-white hover:bg-white/10">
                Discutir Mi Proyecto
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <button
                onClick={closeModal}
                className="absolute top-4 right-4 z-10 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              
              <img 
                src={selectedProject.image} 
                alt={selectedProject.title}
                className="w-full h-64 md:h-96 object-cover rounded-t-lg"
              />
            </div>
            
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold text-primary mb-2">
                    {selectedProject.title}
                  </h2>
                  <div className="flex flex-wrap gap-4 text-muted-foreground">
                    <span>{selectedProject.location}</span>
                    <span>•</span>
                    <span>{selectedProject.year}</span>
                    <span>•</span>
                    <span className="capitalize">
                      {selectedProject.type === 'residential' ? 'Residencial' : 'Comercial'}
                    </span>
                  </div>
                </div>
              </div>
              
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                {selectedProject.details}
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/quote">
                  <Button className="btn-primary">
                    Proyecto Similar
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
                <Link to="/contact">
                  <Button variant="outline">
                    Más Información
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Gallery;


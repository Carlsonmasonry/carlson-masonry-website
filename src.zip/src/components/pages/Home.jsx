import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Shield, Award, CheckCircle, Heart, Star, Phone, Mail } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

// Import images
import heroImage from '../../assets/C1YKTpWsG2qG.jpg';
import brickworkImage from '../../assets/68CPjQfi43Ek.jpg';
import stoneworkImage from '../../assets/BjlXGtMw0xC2.jpg';

const Home = () => {
  const coreValues = [
    {
      icon: Shield,
      title: "Responsabilidad",
      description: "Compromiso total con la entrega puntual y dentro del presupuesto, asumiendo plena responsabilidad por cada proyecto."
    },
    {
      icon: Award,
      title: "Calidad",
      description: "Artesanía superior con materiales de primera calidad y atención meticulosa a cada detalle de construcción."
    },
    {
      icon: CheckCircle,
      title: "Cumplimiento",
      description: "Adherencia estricta a normativas, códigos de construcción y estándares de seguridad para tu tranquilidad."
    },
    {
      icon: Heart,
      title: "Construcción de Sueños",
      description: "Transformamos tus visiones en realidades tangibles, creando espacios duraderos que superan expectativas."
    }
  ];

  const services = [
    {
      title: "Albañilería de Ladrillo",
      description: "Instalación experta de ladrillo para proyectos residenciales y comerciales con acabados impecables.",
      image: brickworkImage,
      features: ["Instalación nueva", "Reparaciones", "Restauración histórica"]
    },
    {
      title: "Instalación de Piedra Natural",
      description: "Hermosas soluciones en piedra natural que añaden elegancia y durabilidad a cualquier proyecto.",
      image: stoneworkImage,
      features: ["Piedra decorativa", "Muros de contención", "Chimeneas"]
    },
    {
      title: "Reparaciones y Restauración",
      description: "Servicios especializados de reparación que devuelven la belleza original a tus estructuras.",
      image: heroImage,
      features: ["Reparación de grietas", "Rejuntado", "Impermeabilización"]
    }
  ];

  const testimonials = [
    {
      name: "María González",
      location: "Little Rock, AR",
      rating: 5,
      text: "Carlson Masonry transformó completamente nuestro patio trasero. Su atención al detalle y profesionalismo fueron excepcionales. Recomiendo ampliamente sus servicios.",
      project: "Patio de Piedra Natural"
    },
    {
      name: "Roberto Silva",
      location: "North Little Rock, AR",
      rating: 5,
      text: "El trabajo en nuestra chimenea superó todas nuestras expectativas. El equipo fue puntual, limpio y el resultado final es simplemente hermoso.",
      project: "Chimenea de Ladrillo"
    },
    {
      name: "Ana Martínez",
      location: "Conway, AR",
      rating: 5,
      text: "Profesionales de primer nivel. Cumplieron con todos los plazos prometidos y la calidad del trabajo es excepcional. Definitivamente los volveríamos a contratar.",
      project: "Muro de Contención"
    }
  ];

  const stats = [
    { number: "15+", label: "Años de Experiencia" },
    { number: "500+", label: "Proyectos Completados" },
    { number: "100%", label: "Clientes Satisfechos" },
    { number: "24/7", label: "Soporte al Cliente" }
  ];

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 hero-gradient"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <h1 className="text-responsive-xl font-bold mb-6 text-shadow fade-in">
            Construimos Tus Sueños con Responsabilidad y Calidad
          </h1>
          <p className="text-responsive-md mb-8 opacity-90 fade-in" style={{ animationDelay: '0.2s' }}>
            Más de 15 años transformando visiones en realidades duraderas en Arkansas. 
            Especialistas en albañilería que combinan tradición, innovación y excelencia.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center fade-in" style={{ animationDelay: '0.4s' }}>
            <Link to="/quote">
              <Button className="btn-primary text-lg px-8 py-4">
                Solicitar Cotización Gratuita
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/gallery">
              <Button variant="outline" className="text-lg px-8 py-4 bg-white/10 border-white/30 text-white hover:bg-white/20">
                Ver Nuestro Trabajo
              </Button>
            </Link>
          </div>
          
          {/* Quick contact */}
          <div className="mt-12 flex flex-col sm:flex-row gap-6 justify-center items-center text-sm fade-in" style={{ animationDelay: '0.6s' }}>
            <div className="flex items-center space-x-2">
              <Phone className="w-4 h-4" />
              <span>(501) 555-0123</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4" />
              <span>info@carlsonmasonryllc.com</span>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Nuestros Valores Fundamentales
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Cada proyecto que emprendemos está respaldado por cuatro pilares fundamentales 
              que definen nuestra identidad y garantizan tu satisfacción.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {coreValues.map((value, index) => (
              <Card key={index} className="card-hover border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <div className="service-icon mb-4">
                    <value.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-primary mb-3">{value.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Nuestros Servicios Especializados
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Desde la mampostería tradicional hasta las instalaciones más modernas, 
              nuestro equipo de expertos está aquí para materializar tus proyectos.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="card-hover overflow-hidden border-0 shadow-lg">
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-primary/20"></div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-primary mb-3">{service.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <CheckCircle className="w-4 h-4 text-accent mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link to="/services">
                    <Button variant="outline" className="w-full">
                      Más Información
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-4xl lg:text-5xl font-bold text-accent">{stat.number}</div>
                <div className="text-lg opacity-90">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Lo Que Dicen Nuestros Clientes
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              La satisfacción de nuestros clientes es nuestro mayor logro. 
              Descubre por qué confían en nosotros para sus proyectos más importantes.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="testimonial-card card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 italic leading-relaxed">
                    "{testimonial.text}"
                  </p>
                  <div className="border-t pt-4">
                    <div className="font-semibold text-primary">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.location}</div>
                    <div className="text-sm text-accent font-medium">{testimonial.project}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/testimonials">
              <Button className="btn-primary">
                Ver Más Testimonios
                <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom text-center">
          <h2 className="text-responsive-lg font-bold mb-4">
            ¿Listo para Construir Tu Sueño?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            Contáctanos hoy mismo para una consulta gratuita. Nuestro equipo de expertos 
            está listo para transformar tu visión en una realidad duradera y hermosa.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/quote">
              <Button className="btn-secondary text-lg px-8 py-4">
                Solicitar Cotización Gratuita
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="text-lg px-8 py-4 border-white/30 text-white hover:bg-white/10">
                Contactar Ahora
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;


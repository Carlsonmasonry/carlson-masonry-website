import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Star, Clock, Shield, Award } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

// Import images
import brickworkImage from '../../assets/68CPjQfi43Ek.jpg';
import stoneworkImage from '../../assets/BjlXGtMw0xC2.jpg';
import repairImage from '../../assets/C1YKTpWsG2qG.jpg';

const Services = () => {
  const services = [
    {
      title: "Albañilería de Ladrillo",
      description: "Instalación experta de ladrillo para proyectos residenciales y comerciales con acabados impecables y durabilidad garantizada.",
      image: brickworkImage,
      features: [
        "Instalación de ladrillo nuevo",
        "Reparación de estructuras existentes",
        "Restauración de edificios históricos",
        "Chimeneas y patios de ladrillo",
        "Muros decorativos y funcionales",
        "Acabados personalizados"
      ],
      benefits: [
        "Durabilidad superior a 50 años",
        "Resistencia a condiciones climáticas extremas",
        "Bajo mantenimiento requerido",
        "Aumento del valor de la propiedad"
      ],
      process: [
        "Consulta inicial y evaluación del sitio",
        "Diseño personalizado y selección de materiales",
        "Preparación del área de trabajo",
        "Instalación profesional con técnicas tradicionales",
        "Inspección de calidad y acabados finales",
        "Limpieza completa y entrega del proyecto"
      ]
    },
    {
      title: "Instalación de Piedra Natural",
      description: "Hermosas soluciones en piedra natural que añaden elegancia, durabilidad y valor a cualquier proyecto arquitectónico.",
      image: stoneworkImage,
      features: [
        "Piedra decorativa para fachadas",
        "Muros de contención y paisajismo",
        "Chimeneas de piedra natural",
        "Patios y senderos de piedra",
        "Elementos arquitectónicos únicos",
        "Restauración de piedra histórica"
      ],
      benefits: [
        "Belleza natural única e irrepetible",
        "Resistencia excepcional al desgaste",
        "Sostenibilidad y respeto ambiental",
        "Versatilidad en diseños y aplicaciones"
      ],
      process: [
        "Selección personalizada de piedra natural",
        "Planificación detallada del proyecto",
        "Preparación especializada del sustrato",
        "Instalación artesanal con técnicas avanzadas",
        "Sellado y protección de la piedra",
        "Mantenimiento inicial y recomendaciones"
      ]
    },
    {
      title: "Reparaciones y Restauración",
      description: "Servicios especializados de reparación que devuelven la belleza original y la integridad estructural a tus construcciones.",
      image: repairImage,
      features: [
        "Reparación de grietas y fisuras",
        "Rejuntado y reemplazo de mortero",
        "Impermeabilización de estructuras",
        "Restauración de edificios históricos",
        "Refuerzo estructural especializado",
        "Mantenimiento preventivo"
      ],
      benefits: [
        "Extensión significativa de la vida útil",
        "Prevención de daños mayores",
        "Conservación del valor patrimonial",
        "Soluciones costo-efectivas"
      ],
      process: [
        "Diagnóstico exhaustivo de daños",
        "Análisis estructural y de materiales",
        "Plan de restauración personalizado",
        "Ejecución con técnicas especializadas",
        "Pruebas de calidad y resistencia",
        "Programa de mantenimiento futuro"
      ]
    }
  ];

  const whyChooseUs = [
    {
      icon: Shield,
      title: "Garantía Total",
      description: "Todos nuestros trabajos incluyen garantía completa de materiales y mano de obra por 5 años."
    },
    {
      icon: Award,
      title: "Experiencia Comprobada",
      description: "Más de 15 años de experiencia y cientos de proyectos exitosos nos respaldan."
    },
    {
      icon: Clock,
      title: "Puntualidad Garantizada",
      description: "Cumplimos religiosamente con los plazos acordados, respetando tu tiempo y presupuesto."
    },
    {
      icon: Star,
      title: "Calidad Premium",
      description: "Utilizamos únicamente materiales de primera calidad y técnicas probadas en el tiempo."
    }
  ];

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container-custom text-center">
          <h1 className="text-responsive-xl font-bold text-primary mb-6">
            Servicios Especializados de Albañilería
          </h1>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Desde la instalación de ladrillo tradicional hasta las más sofisticadas técnicas de piedra natural, 
            nuestro equipo de expertos artesanos está preparado para materializar cualquier visión arquitectónica 
            con la más alta calidad y profesionalismo.
          </p>
        </div>
      </section>

      {/* Services Detail Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="space-y-24">
            {services.map((service, index) => (
              <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
              }`}>
                {/* Image */}
                <div className={`relative ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="rounded-lg shadow-2xl w-full h-auto"
                  />
                  <div className="absolute inset-0 bg-primary/10 rounded-lg"></div>
                </div>

                {/* Content */}
                <div className={`space-y-6 ${index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}`}>
                  <div>
                    <h2 className="text-responsive-lg font-bold text-primary mb-4">
                      {service.title}
                    </h2>
                    <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                      {service.description}
                    </p>
                  </div>

                  {/* Features */}
                  <div>
                    <h3 className="text-xl font-semibold text-primary mb-4">Servicios Incluidos:</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                          <span className="text-muted-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Benefits */}
                  <div>
                    <h3 className="text-xl font-semibold text-primary mb-4">Beneficios Clave:</h3>
                    <ul className="space-y-2">
                      {service.benefits.map((benefit, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <Star className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Link to="/quote">
                    <Button className="btn-primary">
                      Solicitar Cotización
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Nuestro Proceso de Trabajo
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Seguimos un proceso meticuloso y probado que garantiza resultados excepcionales 
              en cada proyecto, sin importar su complejidad o tamaño.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services[0].process.map((step, index) => (
              <Card key={index} className="card-hover border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                    {index + 1}
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{step}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              ¿Por Qué Elegir Nuestros Servicios?
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Nuestro compromiso con la excelencia y la satisfacción del cliente nos distingue 
              como la opción preferida para proyectos de albañilería en Arkansas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, index) => (
              <Card key={index} className="card-hover border-0 shadow-lg text-center">
                <CardContent className="p-6">
                  <div className="service-icon mb-4">
                    <item.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-primary mb-3">{item.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-responsive-lg font-bold mb-4">
              Áreas de Servicio en Arkansas
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Brindamos nuestros servicios especializados en toda la región central de Arkansas, 
              llevando calidad y profesionalismo a tu puerta.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 text-center">
            {[
              'Little Rock', 'North Little Rock', 'Conway', 'Benton',
              'Bryant', 'Sherwood', 'Jacksonville', 'Cabot',
              'Maumelle', 'Hot Springs', 'Pine Bluff', 'Searcy'
            ].map((city, index) => (
              <div key={index} className="py-3 px-4 bg-white/10 rounded-lg">
                <span className="font-medium">{city}</span>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <p className="text-lg opacity-90">
              ¿No ves tu ciudad? <Link to="/contact" className="text-accent hover:underline font-semibold">Contáctanos</Link> para consultar disponibilidad en tu área.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-accent text-accent-foreground">
        <div className="container-custom text-center">
          <h2 className="text-responsive-lg font-bold mb-4">
            ¿Listo para Comenzar Tu Proyecto?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            Nuestro equipo de expertos está listo para transformar tu visión en una realidad hermosa y duradera. 
            Solicita tu cotización gratuita hoy mismo.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/quote">
              <Button className="btn-primary text-lg px-8 py-4">
                Solicitar Cotización Gratuita
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="text-lg px-8 py-4 border-white/30 text-white hover:bg-white/10">
                Contactar Ahora
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;


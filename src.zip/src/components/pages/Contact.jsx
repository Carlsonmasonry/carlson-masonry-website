import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Phone, Mail, MapPin, Clock, Send, CheckCircle } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
    projectType: '',
    timeline: ''
  });
  
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you would typically send the form data to your backend
    console.log('Form submitted:', formData);
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: '',
        message: '',
        projectType: '',
        timeline: ''
      });
    }, 3000);
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Teléfono",
      details: "(501) 555-0123",
      description: "Lunes a Viernes: 7:00 AM - 6:00 PM\nSábados: 8:00 AM - 4:00 PM"
    },
    {
      icon: Mail,
      title: "Correo Electrónico",
      details: "info@carlsonmasonryllc.com",
      description: "Respuesta garantizada en 24 horas\nCotizaciones gratuitas disponibles"
    },
    {
      icon: MapPin,
      title: "Oficina Principal",
      details: "123 Construction Ave\nLittle Rock, AR 72201",
      description: "Visitas con cita previa\nShowroom de materiales disponible"
    },
    {
      icon: Clock,
      title: "Horarios de Servicio",
      details: "Lunes - Viernes: 7:00 AM - 6:00 PM\nSábados: 8:00 AM - 4:00 PM",
      description: "Servicios de emergencia disponibles\n24/7 para clientes existentes"
    }
  ];

  const serviceAreas = [
    "Little Rock", "North Little Rock", "Conway", "Benton",
    "Bryant", "Sherwood", "Jacksonville", "Cabot",
    "Maumelle", "Hot Springs", "Pine Bluff", "Searcy",
    "Alexander", "Hensley", "Shannon Hills", "Traskwood"
  ];

  const projectTypes = [
    "Albañilería de Ladrillo",
    "Instalación de Piedra Natural",
    "Reparaciones y Restauración",
    "Proyecto Comercial",
    "Proyecto Residencial",
    "Chimenea",
    "Patio o Sendero",
    "Muro de Contención",
    "Otro"
  ];

  const timelines = [
    "Lo antes posible",
    "Dentro de 1 mes",
    "1-3 meses",
    "3-6 meses",
    "Más de 6 meses",
    "Solo explorando opciones"
  ];

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container-custom text-center">
          <h1 className="text-responsive-xl font-bold text-primary mb-6">
            Contacta con Nosotros
          </h1>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Estamos aquí para ayudarte a materializar tu proyecto de albañilería. 
            Contáctanos hoy mismo para una consulta gratuita y descubre cómo podemos 
            transformar tu visión en una realidad hermosa y duradera.
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => (
              <Card key={index} className="text-center border-0 shadow-lg card-hover">
                <CardContent className="p-6">
                  <div className="service-icon mb-4">
                    <info.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-primary mb-3">{info.title}</h3>
                  <p className="text-muted-foreground font-medium mb-2 whitespace-pre-line">
                    {info.details}
                  </p>
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {info.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form and Map */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-responsive-lg font-bold text-primary mb-6">
                Envíanos un Mensaje
              </h2>
              <p className="text-muted-foreground mb-8 leading-relaxed">
                Completa el formulario a continuación y nos pondremos en contacto contigo 
                dentro de 24 horas. Para consultas urgentes, no dudes en llamarnos directamente.
              </p>

              {isSubmitted ? (
                <Card className="border-0 shadow-lg bg-green-50 border-green-200">
                  <CardContent className="p-8 text-center">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-green-800 mb-2">
                      ¡Mensaje Enviado Exitosamente!
                    </h3>
                    <p className="text-green-700">
                      Gracias por contactarnos. Nos pondremos en contacto contigo dentro de 24 horas.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-primary mb-2">
                            Nombre Completo *
                          </label>
                          <Input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            className="w-full"
                            placeholder="Tu nombre completo"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-primary mb-2">
                            Correo Electrónico *
                          </label>
                          <Input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                            className="w-full"
                            placeholder="tu@email.com"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-primary mb-2">
                            Teléfono
                          </label>
                          <Input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="w-full"
                            placeholder="(501) 555-0123"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-primary mb-2">
                            Tipo de Proyecto
                          </label>
                          <select
                            name="projectType"
                            value={formData.projectType}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                          >
                            <option value="">Seleccionar tipo de proyecto</option>
                            {projectTypes.map((type, index) => (
                              <option key={index} value={type}>{type}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-primary mb-2">
                            Asunto
                          </label>
                          <Input
                            type="text"
                            name="subject"
                            value={formData.subject}
                            onChange={handleInputChange}
                            className="w-full"
                            placeholder="Asunto de tu consulta"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-primary mb-2">
                            Cronograma Deseado
                          </label>
                          <select
                            name="timeline"
                            value={formData.timeline}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                          >
                            <option value="">Seleccionar cronograma</option>
                            {timelines.map((timeline, index) => (
                              <option key={index} value={timeline}>{timeline}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          Mensaje *
                        </label>
                        <Textarea
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          required
                          rows={6}
                          className="w-full"
                          placeholder="Describe tu proyecto, incluyendo detalles sobre ubicación, tamaño, materiales preferidos, presupuesto estimado y cualquier otra información relevante..."
                        />
                      </div>

                      <Button type="submit" className="btn-primary w-full">
                        Enviar Mensaje
                        <Send className="ml-2 w-4 h-4" />
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Map and Additional Info */}
            <div className="space-y-8">
              <div>
                <h2 className="text-responsive-lg font-bold text-primary mb-6">
                  Nuestra Ubicación
                </h2>
                
                {/* Map Placeholder */}
                <Card className="border-0 shadow-lg mb-6">
                  <CardContent className="p-0">
                    <div className="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                      <div className="text-center text-muted-foreground">
                        <MapPin className="w-12 h-12 mx-auto mb-2" />
                        <p className="font-medium">Mapa Interactivo</p>
                        <p className="text-sm">123 Construction Ave, Little Rock, AR 72201</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <p className="text-muted-foreground leading-relaxed">
                  Nuestra oficina principal está convenientemente ubicada en el corazón de Little Rock, 
                  con fácil acceso desde todas las áreas metropolitanas. Contamos con un showroom donde 
                  puedes ver muestras de nuestros materiales y proyectos anteriores.
                </p>
              </div>

              {/* Service Areas */}
              <div>
                <h3 className="text-xl font-semibold text-primary mb-4">
                  Áreas de Servicio
                </h3>
                <p className="text-muted-foreground mb-4">
                  Brindamos servicios en las siguientes ciudades y áreas circundantes:
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {serviceAreas.map((area, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-accent flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">{area}</span>
                    </div>
                  ))}
                </div>
                <p className="text-sm text-muted-foreground mt-4">
                  ¿No ves tu ciudad? Contáctanos para consultar disponibilidad en tu área.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Contact */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h2 className="text-responsive-lg font-bold mb-4">
              ¿Necesitas Asistencia Urgente?
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Para emergencias estructurales o consultas urgentes, nuestro equipo está disponible 
              24/7 para clientes existentes. Para nuevos clientes, ofrecemos respuesta rápida 
              durante horarios comerciales.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <div className="text-center">
              <Phone className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-lg font-semibold">Llamada Directa</p>
              <p className="text-2xl font-bold text-accent">(501) 555-0123</p>
            </div>
            <div className="hidden sm:block w-px h-16 bg-white/20"></div>
            <div className="text-center">
              <Mail className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-lg font-semibold">Correo Urgente</p>
              <p className="text-lg text-accent">emergency@carlsonmasonryllc.com</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-accent text-accent-foreground">
        <div className="container-custom text-center">
          <h2 className="text-responsive-lg font-bold mb-4">
            ¿Prefieres una Cotización Detallada?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            Si ya tienes detalles específicos sobre tu proyecto, utiliza nuestro formulario 
            de cotización especializado para obtener una estimación más precisa y rápida.
          </p>
          
          <Link to="/quote">
            <Button className="btn-primary text-lg px-8 py-4">
              Solicitar Cotización Detallada
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Contact;


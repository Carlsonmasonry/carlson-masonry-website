import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Upload, Calculator, Clock, Shield } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';

const Quote = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Step 1: Contact Info
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipCode: '',
    
    // Step 2: Project Details
    projectType: '',
    projectSize: '',
    timeline: '',
    budget: '',
    description: '',
    
    // Step 3: Specific Requirements
    materials: [],
    style: '',
    accessibility: '',
    permits: '',
    additionalServices: [],
    
    // Step 4: Final Details
    preferredContact: '',
    bestTime: '',
    additionalInfo: '',
    photos: []
  });
  
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (type === 'checkbox') {
      if (name === 'materials' || name === 'additionalServices') {
        setFormData(prev => ({
          ...prev,
          [name]: checked 
            ? [...prev[name], value]
            : prev[name].filter(item => item !== value)
        }));
      } else {
        setFormData(prev => ({
          ...prev,
          [name]: checked
        }));
      }
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Quote request submitted:', formData);
    setIsSubmitted(true);
  };

  const steps = [
    { number: 1, title: "Información de Contacto", icon: CheckCircle },
    { number: 2, title: "Detalles del Proyecto", icon: Calculator },
    { number: 3, title: "Requisitos Específicos", icon: Upload },
    { number: 4, title: "Finalizar Solicitud", icon: Clock }
  ];

  const projectTypes = [
    "Albañilería de Ladrillo",
    "Instalación de Piedra Natural",
    "Reparaciones y Restauración",
    "Chimenea (Interior/Exterior)",
    "Patio o Sendero",
    "Muro de Contención",
    "Fachada Comercial",
    "Proyecto Residencial Completo",
    "Otro (especificar en descripción)"
  ];

  const materials = [
    "Ladrillo tradicional",
    "Ladrillo moderno",
    "Piedra natural local",
    "Piedra natural importada",
    "Piedra artificial",
    "Concreto decorativo",
    "Mortero especializado",
    "Materiales reciclados"
  ];

  const additionalServices = [
    "Diseño arquitectónico",
    "Permisos y licencias",
    "Excavación y preparación",
    "Impermeabilización",
    "Limpieza post-construcción",
    "Mantenimiento programado",
    "Garantía extendida",
    "Consultoría especializada"
  ];

  if (isSubmitted) {
    return (
      <div className="pt-32">
        <section className="section-padding">
          <div className="container-custom">
            <Card className="max-w-2xl mx-auto border-0 shadow-2xl bg-green-50 border-green-200">
              <CardContent className="p-12 text-center">
                <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
                <h1 className="text-3xl font-bold text-green-800 mb-4">
                  ¡Solicitud de Cotización Enviada!
                </h1>
                <p className="text-lg text-green-700 mb-6 leading-relaxed">
                  Gracias por confiar en Carlson Masonry LLC. Hemos recibido tu solicitud de cotización 
                  y nuestro equipo de expertos la está revisando.
                </p>
                
                <div className="bg-white rounded-lg p-6 mb-6 text-left">
                  <h3 className="font-semibold text-primary mb-3">Próximos Pasos:</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>Revisión de tu solicitud (24 horas)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>Contacto inicial para aclarar detalles (48 horas)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>Visita al sitio si es necesario (3-5 días)</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>Entrega de cotización detallada (5-7 días)</span>
                    </li>
                  </ul>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link to="/">
                    <Button className="btn-primary">
                      Volver al Inicio
                    </Button>
                  </Link>
                  <Link to="/gallery">
                    <Button variant="outline">
                      Ver Nuestros Proyectos
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container-custom text-center">
          <h1 className="text-responsive-xl font-bold text-primary mb-6">
            Solicitar Cotización Gratuita
          </h1>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            Obtén una cotización detallada y personalizada para tu proyecto de albañilería. 
            Nuestro proceso paso a paso nos ayuda a entender exactamente lo que necesitas 
            para brindarte la estimación más precisa posible.
          </p>
        </div>
      </section>

      {/* Progress Indicator */}
      <section className="py-8 bg-white border-b">
        <div className="container-custom">
          <div className="flex justify-center">
            <div className="flex items-center space-x-4 md:space-x-8">
              {steps.map((step, index) => (
                <div key={step.number} className="flex items-center">
                  <div className={`flex items-center space-x-2 ${
                    currentStep >= step.number ? 'text-primary' : 'text-muted-foreground'
                  }`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                      currentStep >= step.number 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-gray-200 text-muted-foreground'
                    }`}>
                      {currentStep > step.number ? (
                        <CheckCircle className="w-5 h-5" />
                      ) : (
                        step.number
                      )}
                    </div>
                    <span className="hidden md:block font-medium">{step.title}</span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-8 md:w-16 h-0.5 mx-2 md:mx-4 ${
                      currentStep > step.number ? 'bg-primary' : 'bg-gray-200'
                    }`}></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Form Section */}
      <section className="section-padding">
        <div className="container-custom max-w-4xl mx-auto">
          <form onSubmit={handleSubmit}>
            {/* Step 1: Contact Information */}
            {currentStep === 1 && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold text-primary mb-6">
                    Información de Contacto
                  </h2>
                  <p className="text-muted-foreground mb-8">
                    Comencemos con tu información básica para poder contactarte con la cotización.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Nombre Completo *
                      </label>
                      <Input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        placeholder="Tu nombre completo"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Correo Electrónico *
                      </label>
                      <Input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        placeholder="tu@email.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Teléfono *
                      </label>
                      <Input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        placeholder="(501) 555-0123"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Ciudad *
                      </label>
                      <Input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        required
                        placeholder="Little Rock"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-primary mb-2">
                        Dirección del Proyecto *
                      </label>
                      <Input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        required
                        placeholder="Dirección completa donde se realizará el proyecto"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Código Postal
                      </label>
                      <Input
                        type="text"
                        name="zipCode"
                        value={formData.zipCode}
                        onChange={handleInputChange}
                        placeholder="72201"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 2: Project Details */}
            {currentStep === 2 && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold text-primary mb-6">
                    Detalles del Proyecto
                  </h2>
                  <p className="text-muted-foreground mb-8">
                    Cuéntanos sobre tu proyecto para poder preparar una cotización precisa.
                  </p>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Tipo de Proyecto *
                      </label>
                      <select
                        name="projectType"
                        value={formData.projectType}
                        onChange={handleInputChange}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      >
                        <option value="">Seleccionar tipo de proyecto</option>
                        {projectTypes.map((type, index) => (
                          <option key={index} value={type}>{type}</option>
                        ))}
                      </select>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          Tamaño Aproximado del Proyecto
                        </label>
                        <select
                          name="projectSize"
                          value={formData.projectSize}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">Seleccionar tamaño</option>
                          <option value="small">Pequeño (menos de 100 pies²)</option>
                          <option value="medium">Mediano (100-500 pies²)</option>
                          <option value="large">Grande (500-1000 pies²)</option>
                          <option value="xlarge">Muy Grande (más de 1000 pies²)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          Cronograma Deseado
                        </label>
                        <select
                          name="timeline"
                          value={formData.timeline}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">Seleccionar cronograma</option>
                          <option value="asap">Lo antes posible</option>
                          <option value="1month">Dentro de 1 mes</option>
                          <option value="3months">1-3 meses</option>
                          <option value="6months">3-6 meses</option>
                          <option value="flexible">Flexible</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Presupuesto Estimado
                      </label>
                      <select
                        name="budget"
                        value={formData.budget}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      >
                        <option value="">Seleccionar rango de presupuesto</option>
                        <option value="under5k">Menos de $5,000</option>
                        <option value="5k-10k">$5,000 - $10,000</option>
                        <option value="10k-25k">$10,000 - $25,000</option>
                        <option value="25k-50k">$25,000 - $50,000</option>
                        <option value="over50k">Más de $50,000</option>
                        <option value="discuss">Prefiero discutirlo</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Descripción del Proyecto *
                      </label>
                      <Textarea
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        required
                        rows={6}
                        placeholder="Describe tu proyecto en detalle: qué quieres construir, reparar o mejorar, estilo preferido, cualquier requisito especial, etc."
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 3: Specific Requirements */}
            {currentStep === 3 && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold text-primary mb-6">
                    Requisitos Específicos
                  </h2>
                  <p className="text-muted-foreground mb-8">
                    Ayúdanos a entender mejor tus preferencias y necesidades específicas.
                  </p>
                  
                  <div className="space-y-8">
                    <div>
                      <label className="block text-sm font-medium text-primary mb-4">
                        Materiales Preferidos (selecciona todos los que apliquen)
                      </label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {materials.map((material, index) => (
                          <label key={index} className="flex items-center space-x-2 cursor-pointer">
                            <input
                              type="checkbox"
                              name="materials"
                              value={material}
                              checked={formData.materials.includes(material)}
                              onChange={handleInputChange}
                              className="rounded border-gray-300 text-primary focus:ring-primary"
                            />
                            <span className="text-sm">{material}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          Estilo Preferido
                        </label>
                        <select
                          name="style"
                          value={formData.style}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">Seleccionar estilo</option>
                          <option value="traditional">Tradicional</option>
                          <option value="modern">Moderno</option>
                          <option value="rustic">Rústico</option>
                          <option value="contemporary">Contemporáneo</option>
                          <option value="historic">Histórico/Clásico</option>
                          <option value="custom">Personalizado</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          ¿Se Necesitan Permisos?
                        </label>
                        <select
                          name="permits"
                          value={formData.permits}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">No estoy seguro</option>
                          <option value="yes">Sí, necesito ayuda con permisos</option>
                          <option value="no">No se necesitan permisos</option>
                          <option value="have">Ya tengo los permisos</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-primary mb-4">
                        Servicios Adicionales (selecciona todos los que necesites)
                      </label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {additionalServices.map((service, index) => (
                          <label key={index} className="flex items-center space-x-2 cursor-pointer">
                            <input
                              type="checkbox"
                              name="additionalServices"
                              value={service}
                              checked={formData.additionalServices.includes(service)}
                              onChange={handleInputChange}
                              className="rounded border-gray-300 text-primary focus:ring-primary"
                            />
                            <span className="text-sm">{service}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 4: Final Details */}
            {currentStep === 4 && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-bold text-primary mb-6">
                    Finalizar Solicitud
                  </h2>
                  <p className="text-muted-foreground mb-8">
                    Últimos detalles para completar tu solicitud de cotización.
                  </p>
                  
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          Método de Contacto Preferido
                        </label>
                        <select
                          name="preferredContact"
                          value={formData.preferredContact}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">Seleccionar método</option>
                          <option value="phone">Teléfono</option>
                          <option value="email">Correo electrónico</option>
                          <option value="text">Mensaje de texto</option>
                          <option value="any">Cualquier método</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-primary mb-2">
                          Mejor Horario para Contactarte
                        </label>
                        <select
                          name="bestTime"
                          value={formData.bestTime}
                          onChange={handleInputChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        >
                          <option value="">Seleccionar horario</option>
                          <option value="morning">Mañana (8AM - 12PM)</option>
                          <option value="afternoon">Tarde (12PM - 5PM)</option>
                          <option value="evening">Noche (5PM - 8PM)</option>
                          <option value="anytime">Cualquier horario</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Información Adicional
                      </label>
                      <Textarea
                        name="additionalInfo"
                        value={formData.additionalInfo}
                        onChange={handleInputChange}
                        rows={4}
                        placeholder="¿Hay algo más que deberíamos saber sobre tu proyecto? Restricciones de acceso, consideraciones especiales, preguntas específicas, etc."
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-primary mb-2">
                        Fotos del Sitio (Opcional)
                      </label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                        <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground mb-2">
                          Sube fotos del área donde se realizará el proyecto
                        </p>
                        <p className="text-xs text-muted-foreground">
                          JPG, PNG o PDF hasta 10MB cada uno
                        </p>
                        <input
                          type="file"
                          multiple
                          accept="image/*,.pdf"
                          className="hidden"
                          id="photos"
                        />
                        <label htmlFor="photos" className="mt-2 inline-block">
                          <Button type="button" variant="outline" className="cursor-pointer">
                            Seleccionar Archivos
                          </Button>
                        </label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              <div>
                {currentStep > 1 && (
                  <Button type="button" variant="outline" onClick={prevStep}>
                    Anterior
                  </Button>
                )}
              </div>
              <div>
                {currentStep < 4 ? (
                  <Button type="button" onClick={nextStep} className="btn-primary">
                    Siguiente
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                ) : (
                  <Button type="submit" className="btn-primary">
                    Enviar Solicitud
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          </form>
        </div>
      </section>

      {/* Why Choose Our Quote Process */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-responsive-lg font-bold mb-4">
              ¿Por Qué Nuestro Proceso de Cotización es Diferente?
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Nuestro proceso detallado nos permite brindarte la cotización más precisa 
              y completa del mercado, sin sorpresas ni costos ocultos.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Calculator,
                title: "Cotización Precisa",
                description: "Análisis detallado de todos los factores para una estimación exacta."
              },
              {
                icon: Clock,
                title: "Respuesta Rápida",
                description: "Cotización completa entregada en máximo 7 días hábiles."
              },
              {
                icon: Shield,
                title: "Sin Compromisos",
                description: "Cotización completamente gratuita sin obligación de contratación."
              },
              {
                icon: CheckCircle,
                title: "Transparencia Total",
                description: "Desglose completo de costos sin sorpresas ni gastos ocultos."
              }
            ].map((feature, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-8 h-8 text-accent-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm opacity-90">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Quote;


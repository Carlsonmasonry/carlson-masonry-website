import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, Quote, MapPin, Calendar } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: "María González",
      location: "Little Rock, AR",
      date: "Marzo 2024",
      rating: 5,
      project: "Patio de Piedra Natural",
      text: "Carlson Masonry transformó completamente nuestro patio trasero. Su atención al detalle y profesionalismo fueron excepcionales. El equipo llegó puntualmente cada día, mantuvo el área de trabajo limpia y el resultado final superó todas nuestras expectativas. La piedra natural que seleccionaron es hermosa y se integra perfectamente con el paisaje existente.",
      highlight: "Superó todas nuestras expectativas"
    },
    {
      id: 2,
      name: "Roberto Silva",
      location: "North Little Rock, AR",
      date: "Enero 2024",
      rating: 5,
      project: "Chimenea de Ladrillo",
      text: "El trabajo en nuestra chimenea fue simplemente espectacular. Desde la consulta inicial hasta la finalización del proyecto, el equipo de Carlson Masonry demostró un nivel de artesanía que rara vez se ve hoy en día. La chimenea no solo es funcional sino que se ha convertido en el punto focal de nuestra sala de estar. Recomiendo ampliamente sus servicios.",
      highlight: "Nivel de artesanía que rara vez se ve"
    },
    {
      id: 3,
      name: "Ana Martínez",
      location: "Conway, AR",
      date: "Febrero 2024",
      rating: 5,
      project: "Muro de Contención",
      text: "Profesionales de primer nivel. Cumplieron con todos los plazos prometidos y la calidad del trabajo es excepcional. Nuestro muro de contención no solo resolvió el problema de erosión que teníamos, sino que añadió un elemento estético hermoso a nuestro jardín. La comunicación durante todo el proyecto fue excelente.",
      highlight: "Cumplieron con todos los plazos prometidos"
    },
    {
      id: 4,
      name: "Carlos Rodríguez",
      location: "Benton, AR",
      date: "Diciembre 2023",
      rating: 5,
      project: "Fachada Comercial",
      text: "Contratamos a Carlson Masonry para la fachada de nuestro nuevo edificio comercial. El proyecto era complejo y requería coordinación con otros contratistas, pero ellos manejaron todo con profesionalismo excepcional. El resultado es una fachada moderna y elegante que ha recibido numerosos elogios de nuestros clientes y la comunidad.",
      highlight: "Profesionalismo excepcional"
    },
    {
      id: 5,
      name: "Laura Fernández",
      location: "Hot Springs, AR",
      date: "Noviembre 2023",
      rating: 5,
      project: "Restauración de Entrada",
      text: "La restauración de la entrada de ladrillo de nuestra casa histórica fue un trabajo delicado que requería experiencia especializada. Carlson Masonry no solo restauró la belleza original sino que también reforzó la estructura para que dure muchos años más. Su conocimiento de técnicas tradicionales es impresionante.",
      highlight: "Conocimiento de técnicas tradicionales impresionante"
    },
    {
      id: 6,
      name: "Miguel Torres",
      location: "Bryant, AR",
      date: "Octubre 2023",
      rating: 5,
      project: "Patio y Sendero",
      text: "Desde el primer día, el equipo de Carlson Masonry demostró por qué son los mejores en su campo. Nuestro patio y sendero de piedra natural han transformado completamente nuestro espacio exterior. La calidad de los materiales y la precisión en la instalación son evidentes en cada detalle. Definitivamente los volveríamos a contratar.",
      highlight: "Los mejores en su campo"
    },
    {
      id: 7,
      name: "Patricia Morales",
      location: "Sherwood, AR",
      date: "Septiembre 2023",
      rating: 5,
      project: "Reparación de Muro",
      text: "Teníamos un muro perimetral con serios problemas estructurales. Carlson Masonry no solo reparó los daños existentes sino que implementó soluciones preventivas para evitar futuros problemas. Su enfoque integral y su honestidad en las recomendaciones nos dieron total confianza en su trabajo.",
      highlight: "Enfoque integral y honestidad"
    },
    {
      id: 8,
      name: "José Ramírez",
      location: "Jacksonville, AR",
      date: "Agosto 2023",
      rating: 5,
      project: "Chimenea Exterior",
      text: "La chimenea exterior que construyeron se ha convertido en el corazón de nuestras reuniones familiares. La atención a los detalles arquitectónicos y la calidad de la construcción son evidentes. El proyecto se completó a tiempo y dentro del presupuesto acordado. Excelente comunicación durante todo el proceso.",
      highlight: "Completado a tiempo y dentro del presupuesto"
    },
    {
      id: 9,
      name: "Carmen Vásquez",
      location: "Cabot, AR",
      date: "Julio 2023",
      rating: 5,
      project: "Entrada Principal",
      text: "La nueva entrada de piedra natural ha transformado completamente la apariencia de nuestra casa. El diseño personalizado que crearon se integra perfectamente con la arquitectura existente. Su experiencia en selección de materiales y técnicas de instalación es evidente en el resultado final. Trabajo excepcional.",
      highlight: "Diseño personalizado perfectamente integrado"
    }
  ];

  const stats = [
    { number: "500+", label: "Clientes Satisfechos" },
    { number: "4.9/5", label: "Calificación Promedio" },
    { number: "100%", label: "Proyectos Completados" },
    { number: "15+", label: "Años de Experiencia" }
  ];

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container-custom text-center">
          <h1 className="text-responsive-xl font-bold text-primary mb-6">
            Lo Que Dicen Nuestros Clientes
          </h1>
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            La satisfacción de nuestros clientes es nuestro mayor logro. Cada testimonio 
            representa una historia de confianza, calidad y sueños hechos realidad. 
            Descubre por qué somos la opción preferida para proyectos de albañilería en Arkansas.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-4xl lg:text-5xl font-bold text-primary">{stat.number}</div>
                <div className="text-lg text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Grid */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="card-hover border-0 shadow-lg h-full">
                <CardContent className="p-6 h-full flex flex-col">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-primary text-lg">{testimonial.name}</h3>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground mt-1">
                        <MapPin className="w-4 h-4" />
                        <span>{testimonial.location}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground mt-1">
                        <Calendar className="w-4 h-4" />
                        <span>{testimonial.date}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </div>

                  {/* Project */}
                  <div className="mb-4">
                    <span className="bg-accent/10 text-accent px-3 py-1 rounded-full text-sm font-medium">
                      {testimonial.project}
                    </span>
                  </div>

                  {/* Quote */}
                  <div className="flex-1 mb-4">
                    <Quote className="w-8 h-8 text-primary/20 mb-2" />
                    <p className="text-muted-foreground leading-relaxed italic">
                      "{testimonial.text}"
                    </p>
                  </div>

                  {/* Highlight */}
                  <div className="border-t pt-4 mt-auto">
                    <p className="text-sm font-medium text-primary">
                      "{testimonial.highlight}"
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Testimonial */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            <Quote className="w-16 h-16 text-accent mx-auto mb-6" />
            <blockquote className="text-2xl md:text-3xl font-light leading-relaxed mb-8">
              "Carlson Masonry no solo construye estructuras excepcionales, construye relaciones 
              duraderas basadas en confianza, calidad y compromiso. Su trabajo habla por sí mismo."
            </blockquote>
            <div className="flex items-center justify-center space-x-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 text-accent fill-current" />
              ))}
            </div>
            <cite className="text-lg opacity-90">
              - Promedio de calificación de nuestros clientes
            </cite>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Nuestro Compromiso con la Satisfacción
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Cada testimonio positivo es el resultado de nuestro proceso meticuloso 
              y nuestro compromiso inquebrantable con la excelencia en cada proyecto.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "Consulta Personalizada",
                description: "Escuchamos atentamente tus necesidades y visión para crear soluciones personalizadas."
              },
              {
                title: "Comunicación Transparente",
                description: "Mantenemos comunicación constante durante todo el proyecto, sin sorpresas."
              },
              {
                title: "Calidad Garantizada",
                description: "Utilizamos solo materiales premium y técnicas probadas para resultados duraderos."
              },
              {
                title: "Seguimiento Post-Proyecto",
                description: "Nuestro compromiso continúa después de la entrega con soporte y mantenimiento."
              }
            ].map((item, index) => (
              <Card key={index} className="text-center border-0 shadow-lg card-hover">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                    {index + 1}
                  </div>
                  <h3 className="text-lg font-semibold text-primary mb-3">{item.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Review Invitation */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              ¿Eres Cliente de Carlson Masonry?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Nos encantaría conocer tu experiencia. Tu testimonio nos ayuda a mejorar 
              continuamente y ayuda a otros clientes a tomar decisiones informadas.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="btn-primary">
                Dejar una Reseña
                <Star className="ml-2 w-4 h-4" />
              </Button>
              <Link to="/contact">
                <Button variant="outline">
                  Compartir Mi Experiencia
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-accent text-accent-foreground">
        <div className="container-custom text-center">
          <h2 className="text-responsive-lg font-bold mb-4">
            ¿Listo para Ser Nuestro Próximo Cliente Satisfecho?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            Únete a los cientos de clientes que han confiado en nosotros para materializar 
            sus sueños. Tu proyecto podría ser nuestro próximo testimonio de éxito.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/quote">
              <Button className="btn-primary text-lg px-8 py-4">
                Solicitar Cotización Gratuita
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="text-lg px-8 py-4 border-white/30 text-white hover:bg-white/10">
                Contactar Ahora
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Testimonials;


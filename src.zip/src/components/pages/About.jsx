import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, Calendar, Award, Shield, CheckCircle, Heart, Target, Eye, Zap } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';

// Import images
import teamImage from '../../assets/wY1YF0qkrOFC.jpg';
import projectImage from '../../assets/C1YKTpWsG2qG.jpg';

const About = () => {
  const timeline = [
    {
      year: "2010",
      title: "Fundación de la Empresa",
      description: "Carlson Masonry LLC fue fundada con la visión de ofrecer servicios de albañilería de la más alta calidad en Arkansas."
    },
    {
      year: "2013",
      title: "Expansión de Servicios",
      description: "Ampliamos nuestros servicios para incluir proyectos comerciales y especializaciones en piedra natural."
    },
    {
      year: "2016",
      title: "Certificaciones Profesionales",
      description: "Obtuvimos certificaciones adicionales y nos convertimos en miembros activos de la Asociación de Contratistas de Arkansas."
    },
    {
      year: "2019",
      title: "Reconocimiento Regional",
      description: "Fuimos reconocidos como una de las empresas de albañilería más confiables de la región central de Arkansas."
    },
    {
      year: "2022",
      title: "Innovación Tecnológica",
      description: "Incorporamos nuevas tecnologías y técnicas modernas manteniendo la tradición artesanal."
    },
    {
      year: "2025",
      title: "Liderazgo en el Sector",
      description: "Continuamos liderando el sector con más de 500 proyectos completados y 100% de satisfacción del cliente."
    }
  ];

  const teamValues = [
    {
      icon: Target,
      title: "Nuestra Misión",
      description: "Transformar las visiones de nuestros clientes en realidades duraderas y hermosas, utilizando técnicas tradicionales de albañilería combinadas con innovación moderna, siempre con el más alto nivel de responsabilidad y calidad."
    },
    {
      icon: Eye,
      title: "Nuestra Visión",
      description: "Ser la empresa de albañilería más respetada y confiable de Arkansas, reconocida por nuestra excelencia en la construcción de sueños y nuestro compromiso inquebrantable con la satisfacción del cliente."
    },
    {
      icon: Zap,
      title: "Nuestros Principios",
      description: "Integridad en cada proyecto, transparencia en cada comunicación, excelencia en cada detalle y compromiso total con la construcción de relaciones duraderas basadas en la confianza mutua."
    }
  ];

  const certifications = [
    "Licencia de Contratista General de Arkansas #AR123456",
    "Certificación en Seguridad Ocupacional OSHA",
    "Miembro de la Asociación de Contratistas de Arkansas (ACA)",
    "Certificación en Restauración de Estructuras Históricas",
    "Seguro de Responsabilidad Civil por $2,000,000",
    "Certificación en Técnicas de Albañilería Sostenible"
  ];

  const stats = [
    { icon: Calendar, number: "15+", label: "Años de Experiencia" },
    { icon: Users, number: "500+", label: "Proyectos Completados" },
    { icon: Award, number: "100%", label: "Clientes Satisfechos" },
    { icon: Shield, number: "0", label: "Accidentes Laborales" }
  ];

  return (
    <div className="pt-32">
      {/* Hero Section */}
      <section className="section-padding bg-gradient-to-br from-primary/5 to-accent/5">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-responsive-xl font-bold text-primary">
                Más de 15 Años Construyendo Sueños en Arkansas
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                En Carlson Masonry LLC, no solo construimos estructuras; construimos sueños, 
                creamos legados y forjamos relaciones duraderas con cada cliente. Desde nuestra 
                fundación en 2010, hemos sido pioneros en combinar la tradición artesanal con 
                las técnicas más modernas de la albañilería.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Nuestro compromiso con la responsabilidad, calidad, cumplimiento y la construcción 
                de sueños nos ha convertido en la empresa de albañilería más confiable de Arkansas, 
                con más de 500 proyectos completados y una tasa de satisfacción del cliente del 100%.
              </p>
              <Link to="/quote">
                <Button className="btn-primary">
                  Trabajar con Nosotros
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
            <div className="relative">
              <img 
                src={teamImage} 
                alt="Equipo de Carlson Masonry trabajando"
                className="rounded-lg shadow-2xl w-full h-auto"
              />
              <div className="absolute inset-0 bg-primary/10 rounded-lg"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center border-0 shadow-lg card-hover">
                <CardContent className="p-6">
                  <div className="service-icon mb-4">
                    <stat.icon className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                  <div className="text-muted-foreground font-medium">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Nuestra Filosofía Empresarial
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Estos son los principios fundamentales que guían cada decisión, cada proyecto 
              y cada interacción con nuestros valiosos clientes.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {teamValues.map((value, index) => (
              <Card key={index} className="card-hover border-0 shadow-lg h-full">
                <CardContent className="p-8 text-center h-full flex flex-col">
                  <div className="service-icon mb-6">
                    <value.icon className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="text-2xl font-semibold text-primary mb-4">{value.title}</h3>
                  <p className="text-muted-foreground leading-relaxed flex-grow">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-responsive-lg font-bold text-primary mb-4">
              Nuestra Historia de Crecimiento
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Un recorrido por los momentos más importantes que han definido nuestra trayectoria 
              y nos han convertido en líderes del sector.
            </p>
          </div>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-0.5 bg-primary/20"></div>
            
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div key={index} className={`relative flex items-center ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}>
                  {/* Timeline dot */}
                  <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-4 h-4 bg-primary rounded-full border-4 border-white shadow-lg z-10"></div>
                  
                  {/* Content */}
                  <div className={`w-full md:w-1/2 ${
                    index % 2 === 0 ? 'md:pr-12 pl-12 md:pl-0' : 'md:pl-12 pl-12'
                  }`}>
                    <Card className="card-hover border-0 shadow-lg">
                      <CardContent className="p-6">
                        <div className="text-2xl font-bold text-accent mb-2">{item.year}</div>
                        <h3 className="text-xl font-semibold text-primary mb-3">{item.title}</h3>
                        <p className="text-muted-foreground leading-relaxed">{item.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-responsive-lg font-bold mb-4">
              Certificaciones y Licencias
            </h2>
            <p className="text-xl opacity-90 max-w-3xl mx-auto">
              Nuestro compromiso con la excelencia está respaldado por las certificaciones 
              y licencias más rigurosas de la industria.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-0.5" />
                <span className="text-lg opacity-90">{cert}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img 
                src={projectImage} 
                alt="Proyecto de alta calidad de Carlson Masonry"
                className="rounded-lg shadow-2xl w-full h-auto"
              />
              <div className="absolute inset-0 bg-accent/10 rounded-lg"></div>
            </div>
            <div className="space-y-6">
              <h2 className="text-responsive-lg font-bold text-primary">
                ¿Por Qué Elegir Carlson Masonry LLC?
              </h2>
              
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <Shield className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-1">Responsabilidad Total</h3>
                    <p className="text-muted-foreground">Asumimos plena responsabilidad por cada aspecto de tu proyecto, desde la planificación hasta la entrega final.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <Award className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-1">Calidad Incomparable</h3>
                    <p className="text-muted-foreground">Utilizamos solo materiales de primera calidad y técnicas probadas para garantizar resultados duraderos.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-1">Cumplimiento Garantizado</h3>
                    <p className="text-muted-foreground">Cumplimos estrictamente con todas las normativas y códigos, asegurando tu tranquilidad total.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <Heart className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-semibold text-primary mb-1">Construcción de Sueños</h3>
                    <p className="text-muted-foreground">No solo construimos estructuras; materializamos tus sueños y visiones más ambiciosas.</p>
                  </div>
                </div>
              </div>
              
              <Link to="/contact">
                <Button className="btn-primary">
                  Contactar Nuestro Equipo
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-accent text-accent-foreground">
        <div className="container-custom text-center">
          <h2 className="text-responsive-lg font-bold mb-4">
            ¿Listo para Hacer Realidad Tu Proyecto?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-3xl mx-auto">
            Con más de 15 años de experiencia y cientos de proyectos exitosos, 
            estamos listos para convertir tu visión en una realidad hermosa y duradera.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/quote">
              <Button className="btn-primary text-lg px-8 py-4">
                Solicitar Cotización Gratuita
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link to="/gallery">
              <Button variant="outline" className="text-lg px-8 py-4 border-white/30 text-white hover:bg-white/10">
                Ver Nuestros Proyectos
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;


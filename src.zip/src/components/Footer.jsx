import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin, Shield, Award, CheckCircle, Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main footer content */}
      <div className="section-padding">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <span className="text-accent-foreground font-bold text-xl">CM</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Carlson Masonry</h3>
                  <p className="text-sm text-gray-400">LLC</p>
                </div>
              </div>
              <p className="text-gray-300 text-sm leading-relaxed">
                Construyendo sueños con responsabilidad, calidad y cumplimiento desde 2010. 
                Especialistas en albañilería que transforman visiones en realidades duraderas.
              </p>
              
              {/* Core Values Icons */}
              <div className="flex space-x-4 pt-2">
                <div className="flex flex-col items-center space-y-1">
                  <Shield className="w-6 h-6 text-accent" />
                  <span className="text-xs text-gray-400">Responsabilidad</span>
                </div>
                <div className="flex flex-col items-center space-y-1">
                  <Award className="w-6 h-6 text-accent" />
                  <span className="text-xs text-gray-400">Calidad</span>
                </div>
                <div className="flex flex-col items-center space-y-1">
                  <CheckCircle className="w-6 h-6 text-accent" />
                  <span className="text-xs text-gray-400">Cumplimiento</span>
                </div>
                <div className="flex flex-col items-center space-y-1">
                  <Heart className="w-6 h-6 text-accent" />
                  <span className="text-xs text-gray-400">Sueños</span>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Enlaces Rápidos</h4>
              <ul className="space-y-2">
                <li>
                  <Link to="/" className="text-gray-300 hover:text-accent transition-colors text-sm">
                    Inicio
                  </Link>
                </li>
                <li>
                  <Link to="/about" className="text-gray-300 hover:text-accent transition-colors text-sm">
                    Acerca de Nosotros
                  </Link>
                </li>
                <li>
                  <Link to="/services" className="text-gray-300 hover:text-accent transition-colors text-sm">
                    Nuestros Servicios
                  </Link>
                </li>
                <li>
                  <Link to="/gallery" className="text-gray-300 hover:text-accent transition-colors text-sm">
                    Galería de Proyectos
                  </Link>
                </li>
                <li>
                  <Link to="/testimonials" className="text-gray-300 hover:text-accent transition-colors text-sm">
                    Testimonios
                  </Link>
                </li>
                <li>
                  <Link to="/quote" className="text-gray-300 hover:text-accent transition-colors text-sm">
                    Solicitar Cotización
                  </Link>
                </li>
              </ul>
            </div>

            {/* Services */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Nuestros Servicios</h4>
              <ul className="space-y-2">
                <li className="text-gray-300 text-sm">Albañilería de Ladrillo</li>
                <li className="text-gray-300 text-sm">Instalación de Piedra Natural</li>
                <li className="text-gray-300 text-sm">Reparaciones y Restauración</li>
                <li className="text-gray-300 text-sm">Proyectos Comerciales</li>
                <li className="text-gray-300 text-sm">Proyectos Residenciales</li>
                <li className="text-gray-300 text-sm">Chimeneas y Patios</li>
              </ul>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold">Contacto</h4>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-gray-300 text-sm">
                      123 Construction Ave<br />
                      Little Rock, AR 72201
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-accent flex-shrink-0" />
                  <p className="text-gray-300 text-sm">(501) 555-0123</p>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-accent flex-shrink-0" />
                  <p className="text-gray-300 text-sm">info@carlsonmasonryllc.com</p>
                </div>
              </div>

              {/* Social Media */}
              <div className="pt-4">
                <h5 className="text-sm font-semibold mb-3">Síguenos</h5>
                <div className="flex space-x-3">
                  <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-accent transition-colors">
                    <Facebook className="w-4 h-4" />
                  </a>
                  <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-accent transition-colors">
                    <Instagram className="w-4 h-4" />
                  </a>
                  <a href="#" className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center hover:bg-accent transition-colors">
                    <Linkedin className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800 py-6">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-center md:text-left">
              <p className="text-gray-400 text-sm">
                © {currentYear} Carlson Masonry LLC. Todos los derechos reservados.
              </p>
            </div>
            <div className="flex flex-wrap justify-center md:justify-end space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-accent transition-colors">
                Política de Privacidad
              </a>
              <a href="#" className="text-gray-400 hover:text-accent transition-colors">
                Términos de Servicio
              </a>
              <a href="#" className="text-gray-400 hover:text-accent transition-colors">
                Licencias y Certificaciones
              </a>
            </div>
          </div>
          
          {/* License info */}
          <div className="mt-4 pt-4 border-t border-gray-800 text-center">
            <p className="text-gray-500 text-xs">
              Licencia de Contratista #AR123456 | Asegurado y Vinculado | Miembro de la Asociación de Contratistas de Arkansas
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

